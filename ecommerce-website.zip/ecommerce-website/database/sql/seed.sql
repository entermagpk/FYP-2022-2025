USE ecommerce_db;
-- The application seed script creates the admin and demo products securely using bcrypt.
-- Run: cd server && npm install && npm run seed
