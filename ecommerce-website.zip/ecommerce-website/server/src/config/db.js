const mongoose = require('mongoose');
const { Sequelize } = require('sequelize');

let sequelize;

async function connectDatabase() {
  const dbType = (process.env.DB_TYPE || 'mongodb').toLowerCase();

  if (dbType === 'mysql') {
    sequelize = new Sequelize(
      process.env.MYSQL_DB,
      process.env.MYSQL_USER,
      process.env.MYSQL_PASSWORD,
      {
        host: process.env.MYSQL_HOST || '127.0.0.1',
        port: Number(process.env.MYSQL_PORT || 3306),
        dialect: 'mysql',
        logging: false
      }
    );
    await sequelize.authenticate();
    console.log('Connected to MySQL/SQL database.');
    return { type: 'mysql', client: sequelize };
  }

  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB.');
  return { type: 'mongodb', client: mongoose.connection };
}

function getSequelize() {
  if (!sequelize) throw new Error('SQL database is not initialized.');
  return sequelize;
}

module.exports = { connectDatabase, getSequelize };
