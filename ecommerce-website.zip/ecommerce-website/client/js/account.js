const { getUser, apiFetch, escapeHtml, money }=ECOM;
document.addEventListener('DOMContentLoaded', async()=>{
 const user=getUser(); if(!user)return location.href='/login.html';
 document.querySelector('#welcome').textContent=`Welcome, ${user.name}`;
 document.querySelector('#profile').innerHTML=`<p><strong>Name:</strong> ${escapeHtml(user.name)}</p><p><strong>Email:</strong> ${escapeHtml(user.email)}</p><p><strong>Role:</strong> ${escapeHtml(user.role)}</p>`;
 try{
  const orders=await apiFetch('/orders'); document.querySelector('#orders').innerHTML=orders.length?orders.map(o=>`<tr><td>#${o.id||o._id}</td><td>${new Date(o.createdAt).toLocaleString()}</td><td>${money(o.total)}</td><td>${escapeHtml(o.status)}</td></tr>`).join(''):'<tr><td colspan="4">No orders yet.</td></tr>';
 }catch(e){document.querySelector('#orders').innerHTML=`<tr><td colspan="4">${escapeHtml(e.message)}</td></tr>`}
});
