const { apiFetch, addToCart, money, escapeHtml } = ECOM;
document.addEventListener('DOMContentLoaded', async()=>{
 const id=new URLSearchParams(location.search).get('id'); const host=document.querySelector('#product-detail');
 if(!id){host.innerHTML='<div class="error">Missing product id.</div>';return}
 try{
  const p=await apiFetch('/products/'+encodeURIComponent(id));
  host.innerHTML=`<div class="two-col"><div><img class="product-img" style="height:460px;border-radius:18px" src="${p.image}" alt="${escapeHtml(p.name)}"></div><div class="summary"><span class="pill">${escapeHtml(p.category||'General')}</span><h1>${escapeHtml(p.name)}</h1><p class="muted">${escapeHtml(p.description||'')}</p><div class="price" style="font-size:32px">${money(p.price)}</div><p class="small muted">Stock: ${p.stock}</p><button class="btn full" id="add">Add to Cart</button></div></div>`;
  document.querySelector('#add').onclick=()=>{addToCart(p);document.querySelector('#add').textContent='Added to Cart ✓'};
 }catch(e){host.innerHTML=`<div class="error">${escapeHtml(e.message)}</div>`}
});
