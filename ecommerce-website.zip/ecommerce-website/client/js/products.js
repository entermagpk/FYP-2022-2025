const { apiFetch, addToCart, escapeHtml, money } = ECOM;
let allProducts=[];

document.addEventListener('DOMContentLoaded', async()=>{
  const grid=document.querySelector('#products-grid'); if(!grid) return;
  const search=document.querySelector('#search'); const category=document.querySelector('#category');
  async function load(){
    grid.innerHTML='<p class="muted">Loading products...</p>';
    const qs=new URLSearchParams(); if(search.value.trim())qs.set('search',search.value.trim()); if(category.value)qs.set('category',category.value);
    try{ allProducts=await apiFetch('/products?'+qs.toString()); render(allProducts); }catch(e){grid.innerHTML=`<div class="error">${escapeHtml(e.message)}</div>`}
  }
  function render(products){
    grid.innerHTML=products.length?products.map(productCard).join(''):'<p class="muted">No products found.</p>';
    grid.querySelectorAll('[data-add]').forEach(btn=>btn.onclick=()=>{const p=allProducts.find(x=>String(x.id||x._id)===btn.dataset.add);addToCart(p);btn.textContent='Added ✓';setTimeout(()=>btn.textContent='Add to Cart',800)});
    grid.querySelectorAll('[data-view]').forEach(a=>a.href='/product.html?id='+encodeURIComponent(a.dataset.view));
  }
  search.addEventListener('input',()=>load()); category.addEventListener('change',load); load();
});

function productCard(p){
 const id=p.id||p._id;
 return `<article class="card"><a data-view="${id}" href="/product.html?id=${id}"><img class="product-img" src="${p.image}" alt="${escapeHtml(p.name)}"></a><div class="card-body"><span class="pill">${escapeHtml(p.category||'General')}</span><h3>${escapeHtml(p.name)}</h3><div class="row"><span class="price">${money(p.price)}</span><button class="btn" data-add="${id}">Add to Cart</button></div></div></article>`;
}
