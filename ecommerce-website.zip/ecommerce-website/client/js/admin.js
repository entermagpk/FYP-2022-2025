const { getUser, apiFetch, escapeHtml, money }=ECOM;
document.addEventListener('DOMContentLoaded', async()=>{
 const user=getUser(); if(user?.role!=='admin') return location.href='/';
 const form=document.querySelector('#product-form'), msg=document.querySelector('#msg'), table=document.querySelector('#products-table');
 async function load(){const products=await apiFetch('/products');table.innerHTML=products.map(p=>`<tr><td>${escapeHtml(p.name)}</td><td>${escapeHtml(p.category||'')}</td><td>${money(p.price)}</td><td>${p.stock}</td><td><button class="btn danger small" data-delete="${p.id||p._id}">Delete</button></td></tr>`).join('');table.querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('Delete this product?'))return;await apiFetch('/products/'+b.dataset.delete,{method:'DELETE'});load()})}
 form.onsubmit=async e=>{e.preventDefault();try{await apiFetch('/products',{method:'POST',body:JSON.stringify({name:form.name.value,slug:form.slug.value,description:form.description.value,price:Number(form.price.value),stock:Number(form.stock.value),category:form.category.value,image:form.image.value})});msg.innerHTML='<div class="success">Product added.</div>';form.reset();load()}catch(err){msg.innerHTML=`<div class="error">${escapeHtml(err.message)}</div>`}};
 load();
});
