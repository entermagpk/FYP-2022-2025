const API = '/api';

function getToken(){ return localStorage.getItem('token'); }
function getUser(){ try{return JSON.parse(localStorage.getItem('user')||'null')}catch{return null} }
function setSession(data){ localStorage.setItem('token', data.token); localStorage.setItem('user', JSON.stringify(data.user)); }
function clearSession(){ localStorage.removeItem('token'); localStorage.removeItem('user'); }

async function apiFetch(path, options={}){
  const headers = {'Content-Type':'application/json', ...(options.headers||{})};
  const token = getToken();
  if(token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(API + path, {...options, headers});
  const data = await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.message || 'Request failed');
  return data;
}

function cart(){ return JSON.parse(localStorage.getItem('cart') || '[]'); }
function saveCart(items){ localStorage.setItem('cart', JSON.stringify(items)); updateCartBadge(); }
function addToCart(product){
  const items = cart(); const found = items.find(i => String(i.id)===String(product.id||product._id));
  const id = product.id || product._id;
  if(found) found.quantity += 1; else items.push({id,name:product.name,price:Number(product.price),image:product.image,quantity:1});
  saveCart(items);
}
function updateQty(id, qty){ const items=cart().map(i=>String(i.id)===String(id)?({...i,quantity:Math.max(1,qty)}):i); saveCart(items); }
function removeFromCart(id){ saveCart(cart().filter(i=>String(i.id)!==String(id))); }
function cartTotal(){ return cart().reduce((sum,i)=>sum + i.price*i.quantity, 0); }
function updateCartBadge(){ document.querySelectorAll('[data-cart-count]').forEach(el=>el.textContent = cart().reduce((s,i)=>s+i.quantity,0)); }
function money(v){ return `$${Number(v).toFixed(2)}`; }
function escapeHtml(s=''){ return s.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

window.ECOM = {apiFetch,getToken,getUser,setSession,clearSession,cart,saveCart,addToCart,updateQty,removeFromCart,cartTotal,updateCartBadge,money,escapeHtml};
