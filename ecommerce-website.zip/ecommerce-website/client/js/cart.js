const { cart, updateQty, removeFromCart, cartTotal, money, escapeHtml, apiFetch, getUser }=ECOM;
document.addEventListener('DOMContentLoaded',()=>{
 const host=document.querySelector('#cart-items'), total=document.querySelector('#cart-total'); if(!host)return;
 function render(){
  const items=cart();
  host.innerHTML=items.length?items.map(i=>`<div class="cart-item"><img src="${i.image}" alt=""><div><strong>${escapeHtml(i.name)}</strong><div class="muted">${money(i.price)} each</div><div class="qty"><button data-minus="${i.id}">−</button><span>${i.quantity}</span><button data-plus="${i.id}">+</button></div></div><div><strong>${money(i.price*i.quantity)}</strong><br><button class="btn secondary small" data-remove="${i.id}">Remove</button></div></div>`).join(''):'<div class="notice">Your cart is empty. <a href="/products.html">Shop products</a>.</div>';
  total.textContent=money(cartTotal());
  host.querySelectorAll('[data-minus]').forEach(b=>b.onclick=()=>{const i=cart().find(x=>String(x.id)===b.dataset.minus);updateQty(i.id,i.quantity-1);render()});
  host.querySelectorAll('[data-plus]').forEach(b=>b.onclick=()=>{const i=cart().find(x=>String(x.id)===b.dataset.plus);updateQty(i.id,i.quantity+1);render()});
  host.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{removeFromCart(b.dataset.remove);render()});
 }
 document.querySelector('#checkout-btn').onclick=()=>{if(!cart().length)return alert('Your cart is empty.'); if(!getUser()) return location.href='/login.html?next=/checkout.html'; location.href='/checkout.html'};
 render();
});
