const { apiFetch, setSession, escapeHtml } = ECOM;

document.addEventListener('DOMContentLoaded',()=>{
 const login=document.querySelector('#login-form'); const register=document.querySelector('#register-form');
 if(login) login.onsubmit=async e=>{e.preventDefault();const msg=document.querySelector('#msg');try{const data=await apiFetch('/auth/login',{method:'POST',body:JSON.stringify({email:login.email.value,password:login.password.value})});setSession(data);location.href='/account.html'}catch(err){msg.innerHTML=`<div class="error">${escapeHtml(err.message)}</div>`}};
 if(register) register.onsubmit=async e=>{e.preventDefault();const msg=document.querySelector('#msg');try{await apiFetch('/auth/register',{method:'POST',body:JSON.stringify({name:register.name.value,email:register.email.value,password:register.password.value})});const data=await apiFetch('/auth/login',{method:'POST',body:JSON.stringify({email:register.email.value,password:register.password.value})});setSession(data);location.href='/account.html'}catch(err){msg.innerHTML=`<div class="error">${escapeHtml(err.message)}</div>`}};
});
