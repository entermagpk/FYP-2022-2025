require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const { connectDatabase, getSequelize } = require('./src/config/db');
const authRoutes = require('./src/routes/auth');
const productRoutes = require('./src/routes/products');
const orderRoutes = require('./src/routes/orders');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (req, res) => res.json({ ok: true, database: (process.env.DB_TYPE || 'mongodb').toLowerCase() }));
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);

app.use(express.static(path.join(__dirname, '../client')));
app.use((req, res, next) => {
  if (req.method === 'GET' && req.accepts('html')) {
    return res.sendFile(path.join(__dirname, '../client/index.html'));
  }
  next();
});

const port = Number(process.env.PORT || 5000);

(async () => {
  try {
    const db = await connectDatabase();
    if (db.type === 'mysql') await getSequelize().sync();
    app.listen(port, () => console.log(`E-commerce app running at http://localhost:${port}`));
  } catch (error) {
    console.error('Startup failed:', error.message);
    process.exit(1);
  }
})();
