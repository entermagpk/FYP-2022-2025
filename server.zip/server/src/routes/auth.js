const express = require('express');
const jwt = require('jsonwebtoken');
const { createUser, findUserByEmail, bcrypt } = require('../db/repository');
const { auth } = require('../middleware/auth');

const router = express.Router();

function publicUser(user) {
  return {
    id: user.id || user._id,
    name: user.name,
    email: user.email,
    role: user.role
  };
}

router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6) {
      return res.status(400).json({ message: 'Name, email and a 6+ character password are required.' });
    }
    const existing = await findUserByEmail(email);
    if (existing) return res.status(409).json({ message: 'Email is already registered.' });
    const user = await createUser({ name, email, password });
    return res.status(201).json({ user: publicUser(user) });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await findUserByEmail(email || '');
    if (!user) return res.status(401).json({ message: 'Invalid email or password.' });
    const ok = await bcrypt.compare(password || '', user.passwordHash);
    if (!ok) return res.status(401).json({ message: 'Invalid email or password.' });
    const payload = { id: user.id || user._id.toString(), role: user.role };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });
    return res.json({ token, user: publicUser(user) });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

router.get('/me', auth, async (req, res) => {
  res.json({ user: publicUser(req.user) });
});

module.exports = router;
