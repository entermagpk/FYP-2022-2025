const express = require('express');
const { createOrder, listOrders } = require('../db/repository');
const { auth } = require('../middleware/auth');

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const { items, total, shippingAddress } = req.body;
    if (!Array.isArray(items) || items.length === 0 || !shippingAddress || Number(total) <= 0) {
      return res.status(400).json({ message: 'Cart items, total and shipping address are required.' });
    }
    const order = await createOrder({
      userId: req.user.id || req.user._id,
      items,
      total: Number(total),
      shippingAddress,
      status: 'pending'
    });
    res.status(201).json(order);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/', auth, async (req, res) => {
  try {
    const orders = await listOrders(req.user.id || req.user._id, req.user.role);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
