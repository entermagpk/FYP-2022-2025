const bcrypt = require('bcryptjs');

function isMongo() {
  return (process.env.DB_TYPE || 'mongodb').toLowerCase() !== 'mysql';
}

function mongo() {
  return require('./models-mongo');
}

function sql() {
  return require('./models-sql');
}

async function findUserByEmail(email) {
  if (isMongo()) return mongo().User.findOne({ email: email.toLowerCase() });
  return sql().User.findOne({ where: { email: email.toLowerCase() } });
}

async function findUserById(id) {
  if (isMongo()) return mongo().User.findById(id);
  return sql().User.findByPk(id);
}

async function createUser({ name, email, password, role = 'user' }) {
  const passwordHash = await bcrypt.hash(password, 12);
  if (isMongo()) return mongo().User.create({ name, email: email.toLowerCase(), passwordHash, role });
  return sql().User.create({ name, email: email.toLowerCase(), passwordHash, role });
}

async function listProducts({ category, search }) {
  if (isMongo()) {
    const filter = {};
    if (category) filter.category = category;
    if (search) filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];
    return mongo().Product.find(filter).sort({ createdAt: -1 });
  }

  const { Op } = require('sequelize');
  const where = {};
  if (category) where.category = category;
  if (search) where[Op.or] = [
    { name: { [Op.like]: `%${search}%` } },
    { description: { [Op.like]: `%${search}%` } }
  ];
  return sql().Product.findAll({ where, order: [['createdAt', 'DESC']] });
}

async function findProductById(id) {
  if (isMongo()) return mongo().Product.findById(id);
  return sql().Product.findByPk(id);
}

async function findProductBySlug(slug) {
  if (isMongo()) return mongo().Product.findOne({ slug });
  return sql().Product.findOne({ where: { slug } });
}

async function createProduct(data) {
  if (isMongo()) return mongo().Product.create(data);
  return sql().Product.create(data);
}

async function deleteProduct(id) {
  if (isMongo()) return mongo().Product.findByIdAndDelete(id);
  return sql().Product.destroy({ where: { id } });
}

async function createOrder(data) {
  if (isMongo()) return mongo().Order.create(data);
  return sql().Order.create(data);
}

async function listOrders(userId, role) {
  if (isMongo()) {
    const filter = role === 'admin' ? {} : { userId };
    return mongo().Order.find(filter).sort({ createdAt: -1 });
  }
  const where = role === 'admin' ? {} : { userId };
  return sql().Order.findAll({ where, order: [['createdAt', 'DESC']] });
}

module.exports = {
  findUserByEmail,
  findUserById,
  createUser,
  listProducts,
  findProductById,
  findProductBySlug,
  createProduct,
  deleteProduct,
  createOrder,
  listOrders,
  bcrypt
};
