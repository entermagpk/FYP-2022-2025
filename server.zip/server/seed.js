require('dotenv').config();
const { connectDatabase, getSequelize } = require('./src/config/db');
const { createUser, findUserByEmail, createProduct } = require('./src/db/repository');

const products = [
  { name: 'Wireless Headphones', slug: 'wireless-headphones', description: 'Comfortable over-ear headphones with clear sound and long battery life.', price: 49.99, stock: 25, category: 'Electronics', image: 'https://placehold.co/600x400?text=Headphones' },
  { name: 'Smart Watch Pro', slug: 'smart-watch-pro', description: 'Fitness tracking, notifications and everyday health-focused features.', price: 79.99, stock: 18, category: 'Electronics', image: 'https://placehold.co/600x400?text=Smart+Watch' },
  { name: 'Premium Backpack', slug: 'premium-backpack', description: 'Durable multi-compartment backpack for travel, study and work.', price: 39.99, stock: 30, category: 'Fashion', image: 'https://placehold.co/600x400?text=Backpack' },
  { name: 'Running Shoes', slug: 'running-shoes', description: 'Lightweight everyday runners with cushioned comfort.', price: 59.99, stock: 20, category: 'Fashion', image: 'https://placehold.co/600x400?text=Running+Shoes' }
];

(async () => {
  await connectDatabase();
  if ((process.env.DB_TYPE || 'mongodb').toLowerCase() === 'mysql') await getSequelize().sync();

  const adminEmail = 'admin@example.com';
  if (!await findUserByEmail(adminEmail)) {
    await createUser({ name: 'Admin', email: adminEmail, password: 'Admin@12345', role: 'admin' });
  }

  const all = await require('./src/db/repository').listProducts({});
  if (!all.length) {
    for (const product of products) await createProduct(product);
  }
  console.log('Seed complete. Admin: admin@example.com / Admin@12345');
  process.exit(0);
})().catch(err => { console.error(err); process.exit(1); });
