const { apiFetch, getUser, clearSession, updateCartBadge, money } = ECOM;

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  const user = getUser();
  document
    .querySelectorAll("[data-auth-only]")
    .forEach((el) => el.classList.toggle("hidden", !user));
  document
    .querySelectorAll("[data-admin-only]")
    .forEach((el) => el.classList.toggle("hidden", user?.role !== "admin"));
  document.querySelectorAll("[data-login-link]").forEach((el) => {
    el.textContent = user ? `Hi, ${user.name}` : "Login";
    el.href = user ? "/account.html" : "/login.html";
  });
  const logout = document.querySelector("[data-logout]");
  if (logout)
    logout.onclick = (e) => {
      e.preventDefault();
      clearSession();
      location.href = "/";
    };
  loadFeatured();
});

async function loadFeatured() {
  const host = document.querySelector("#featured-products");
  if (!host) return;
  try {
    const products = await apiFetch("/products");
    host.innerHTML = products.slice(0, 4).map(productCard).join("");
    host.querySelectorAll("[data-add]").forEach(
      (btn) =>
        (btn.onclick = () => {
          const p = products.find(
            (x) => String(x.id || x._id) === btn.dataset.add,
          );
          ECOM.addToCart(p);
          btn.textContent = "Added ✓";
          setTimeout(() => (btn.textContent = "Add to Cart"), 900);
        }),
    );
  } catch (e) {
    host.innerHTML = `<div class="error">${ECOM.escapeHtml(e.message)}</div>`;
  }
}

function productCard(p) {
  const id = p.id || p._id;
  return `<article class="card"><img class="product-img" src="${p.image}" alt="${ECOM.escapeHtml(p.name)}"><div class="card-body"><span class="pill">${ECOM.escapeHtml(p.category || "General")}</span><h3>${ECOM.escapeHtml(p.name)}</h3><p class="muted small">${ECOM.escapeHtml((p.description || "").slice(0, 90))}</p><div class="row"><span class="price">${money(p.price)}</span><button class="btn" data-add="${id}">Add to Cart</button></div></div></article>`;
}
window.productCard = productCard;
