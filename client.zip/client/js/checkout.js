const { cart, cartTotal, money, apiFetch, getUser, clearSession, escapeHtml } =
  ECOM;
document.addEventListener("DOMContentLoaded", () => {
  if (!getUser()) return (location.href = "/login.html?next=/checkout.html");
  const summary = document.querySelector("#checkout-summary"),
    form = document.querySelector("#checkout-form"),
    msg = document.querySelector("#msg");
  summary.innerHTML =
    cart()
      .map(
        (i) =>
          `<div class="row"><span>${escapeHtml(i.name)} × ${i.quantity}</span><strong>${money(i.price * i.quantity)}</strong></div>`,
      )
      .join("") +
    `<hr><div class="row"><strong>Total</strong><strong>${money(cartTotal())}</strong></div>`;
  form.onsubmit = async (e) => {
    e.preventDefault();
    try {
      await apiFetch("/orders", {
        method: "POST",
        body: JSON.stringify({
          items: cart(),
          total: cartTotal(),
          shippingAddress: form.address.value,
        }),
      });
      localStorage.removeItem("cart");
      msg.innerHTML =
        '<div class="success">Order placed successfully. Thank you!</div>';
      form.reset();
      setTimeout(() => (location.href = "/account.html"), 900);
    } catch (err) {
      msg.innerHTML = `<div class="error">${escapeHtml(err.message)}</div>`;
    }
  };
});
